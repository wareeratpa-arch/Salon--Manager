# 📖 คู่มือ Deploy เว็บแอป Salon Manager
## ใช้เวลาประมาณ 20-30 นาที | ฟรีทั้งหมด

---

## ขั้นที่ 1 — สร้าง Firebase Project (Database)

1. ไปที่ https://console.firebase.google.com
2. กด **"Create a project"** หรือ **"Add project"**
3. ตั้งชื่อ project เช่น `peaches-salon` → กด Continue
4. ปิด Google Analytics → กด **"Create project"**
5. รอสักครู่ แล้วกด **"Continue"**

### สร้าง Firestore Database
1. เมนูซ้าย → **"Firestore Database"**
2. กด **"Create database"**
3. เลือก **"Start in test mode"** → Next
4. เลือก location: **"asia-southeast1 (Singapore)"** → Enable

### คัดลอก Firebase Config
1. เมนูซ้าย → กดไอคอน ⚙️ (Project settings)
2. เลื่อนลงหา **"Your apps"** → กด **"</>"** (Web app)
3. ตั้งชื่อ app: `salon-web` → กด **"Register app"**
4. คัดลอก code ในส่วน `firebaseConfig = { ... }` ไว้ก่อน
5. กด **"Continue to console"**

---

## ขั้นที่ 2 — ใส่ Firebase Config ในโค้ด

เปิดไฟล์ **`src/firebase.js`** แล้วแทนที่ค่าต่างๆ:

```js
const firebaseConfig = {
  apiKey: "AIza...",           // ← วางค่าจาก Firebase
  authDomain: "peaches-salon.firebaseapp.com",
  projectId: "peaches-salon",
  storageBucket: "peaches-salon.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123"
};
```

---

## ขั้นที่ 3 — ตั้งค่า Firestore Rules

1. ใน Firebase Console → **Firestore Database** → แท็บ **"Rules"**
2. ลบ rule เดิมออกทั้งหมด แล้วใส่ code นี้แทน:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /transactions/{doc} {
      allow read, write: if true;
    }
    match /config/{doc} {
      allow read, write: if true;
    }
  }
}
```

3. กด **"Publish"**

---

## ขั้นที่ 4 — สร้าง GitHub Account และ Upload โค้ด

### สร้าง GitHub Account
1. ไปที่ https://github.com → **Sign up**
2. ใส่ email, password, username → Verify

### Upload โค้ด
1. ไปที่ https://github.com/new
2. ตั้งชื่อ repository: `salon-manager`
3. เลือก **Public** → กด **"Create repository"**
4. กดปุ่ม **"uploading an existing file"**
5. ลากไฟล์ทั้งหมดในโฟลเดอร์ `salon-app` ขึ้นไป
   ⚠️ ต้องอัปโหลดทั้งโฟลเดอร์ `src/` และ `public/` ด้วย
6. กด **"Commit changes"**

---

## ขั้นที่ 5 — Deploy ด้วย Vercel (ได้ URL ฟรี)

1. ไปที่ https://vercel.com → **Sign up with GitHub**
2. กด **"New Project"**
3. เลือก repository `salon-manager` → กด **"Import"**
4. ไม่ต้องแก้อะไร → กด **"Deploy"**
5. รอ 1-2 นาที → ได้ URL เช่น `https://salon-manager-xxx.vercel.app`

**ส่ง URL นี้ให้ทีมงานได้เลยครับ!** 🎉

---

## 🔄 อัปเดตโค้ดในอนาคต

ถ้าต้องการแก้ไขแอป ให้อัปโหลดไฟล์ที่แก้แล้วขึ้น GitHub อีกครั้ง
Vercel จะ deploy ให้อัตโนมัติทันที

---

## ❓ มีปัญหา?

แจ้งผมได้เลยครับ พร้อมช่วยแก้ไข 😊
