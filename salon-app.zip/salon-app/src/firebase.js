// src/firebase.js
// ⚠️ แทนที่ค่าเหล่านี้ด้วย config จาก Firebase Console ของคุณ
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCwk3M4eQKIzod5V_yljBzfU2PCyV--Y0U",
  authDomain: "peachesnail-salon.firebaseapp.com",
  projectId: "peachesnail-salon",
  storageBucket: "peachesnail-salon.firebasestorage.app",
  messagingSenderId: "882657605064",
  appId: "1:882657605064:web:3ab10b9de1ab167ae87cfd"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
