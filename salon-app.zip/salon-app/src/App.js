// src/App.js
import { useState, useEffect } from "react";
import {
  collection, addDoc, deleteDoc, doc,
  onSnapshot, query, orderBy, serverTimestamp,
  setDoc, getDoc
} from "firebase/firestore";
import { db } from "./firebase";

// ─── Constants ────────────────────────────────────────────────────────────────
const BRANCHES = ["Peaches Nails", "Be On Hand"];

const DEFAULT_STAFF = [
  { name: "น้ำผึ้ง",  dailyRate: 400, commRate: 10 },
  { name: "ครีม",    dailyRate: 400, commRate: 10 },
  { name: "ฝ้าย",    dailyRate: 500, commRate: 10 },
  { name: "กล้วย",   dailyRate: 300, commRate: 10 },
  { name: "ออม",     dailyRate: 300, commRate: 10 },
  { name: "แอม",     dailyRate: 400, commRate: 10 },
  { name: "นาเดีย",  dailyRate: 400, commRate: 15 },
  { name: "มุก",     dailyRate: 600, commRate: 10 },
  { name: "ชุ",      dailyRate: 300, commRate: 30 },
];

const SERVICE_CATS = [
  "ทำเล็บมือ", "ทำเล็บเท้า", "ทำเล็บ มือ+เท้า",
  "สปามือ", "สปาเท้า", "สปา มือ+เท้า",
  "เล็บ+สปา", "ต่อขนตา", "Lifting ขนตา",
  "Wax", "Shape คิ้ว", "อื่นๆ",
];

const EXPENSE_CATS = [
  "ค่าแรง", "ค่าเช่าที่", "อุปกรณ์ทำเล็บ",
  "อุปกรณ์สปา", "เบ็ดเตล็ด", "ค่าน้ำ/ไฟ",
  "Internet", "ค่ารถ", "ค่าอาหาร-น้ำดื่ม", "ส่วนตัว", "อื่นๆ",
];

const PAYMENT_METHODS = ["โอน", "เงินสด", "รูดบัตร"];

const todayStr = () => new Date().toISOString().slice(0, 10);
const thisMonthStr = () => todayStr().slice(0, 7);
const fmt = (n) => (n || 0).toLocaleString("th-TH");

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState("dashboard");
  const [branch, setBranch] = useState("Peaches Nails");
  const [transactions, setTransactions] = useState([]);
  const [staff, setStaff] = useState(DEFAULT_STAFF);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(null);
  const [toast, setToast] = useState(null);

  // ── Load staff config from Firestore ──
  useEffect(() => {
    const ref = doc(db, "config", "staff");
    getDoc(ref).then(snap => {
      if (snap.exists()) setStaff(snap.data().list);
    });
  }, []);

  // ── Real-time transactions listener ──
  useEffect(() => {
    const q = query(collection(db, "transactions"), orderBy("createdAt", "desc"));
    const unsub = onSnapshot(q, snap => {
      setTransactions(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });
    return unsub;
  }, []);

  const showToast = (msg, type = "ok") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 2600);
  };

  const addTx = async (tx) => {
    await addDoc(collection(db, "transactions"), {
      ...tx,
      createdAt: serverTimestamp(),
    });
    showToast("บันทึกสำเร็จ ✓");
    setModal(null);
  };

  const delTx = async (id) => {
    if (!window.confirm("ลบรายการนี้?")) return;
    await deleteDoc(doc(db, "transactions", id));
    showToast("ลบแล้ว", "warn");
  };

  const saveStaff = async (list) => {
    setStaff(list);
    await setDoc(doc(db, "config", "staff"), { list });
    showToast("บันทึกการตั้งค่าแล้ว ✓");
    setModal(null);
  };

  // ── Computed ──
  const today = todayStr();
  const month = thisMonthStr();
  const todayTx = transactions.filter(t => t.date === today);
  const todayIncome = todayTx.filter(t => t.type === "income").reduce((s, t) => s + t.amount, 0);
  const todayExpense = todayTx.filter(t => t.type === "expense").reduce((s, t) => s + t.amount, 0);
  const monthIncome = transactions.filter(t => t.type === "income" && t.date?.startsWith(month));
  const monthExpense = transactions.filter(t => t.type === "expense" && t.date?.startsWith(month));

  const commRows = staff.map(s => {
    const sales = monthIncome.filter(t => t.staffName === s.name).reduce((a, t) => a + t.amount, 0);
    return { ...s, sales, comm: Math.round(sales * s.commRate / 100) };
  }).filter(s => s.sales > 0);

  if (loading) return (
    <div style={S.splash}>
      <div style={S.splashGem}>◆</div>
      <p style={S.splashText}>กำลังโหลด...</p>
    </div>
  );

  return (
    <div style={S.root}>
      <Toast toast={toast} />

      {/* Header */}
      <header style={S.header}>
        <div style={S.headerRow}>
          <div style={S.brand}>
            <span style={S.gem}>◆</span>
            <span style={S.brandName}>Peaches &amp; Be On Hand</span>
          </div>
          <button style={S.settingsBtn} onClick={() => setModal("settings")}>⚙</button>
        </div>
        <div style={S.branchRow}>
          {BRANCHES.map(b => (
            <button key={b}
              style={{ ...S.branchBtn, ...(branch === b ? S.branchActive : {}) }}
              onClick={() => setBranch(b)}>
              {b === "Peaches Nails" ? "🌸 " : "🤲 "}{b}
            </button>
          ))}
        </div>
      </header>

      {/* Nav */}
      <nav style={S.nav}>
        {[["dashboard","📊 ภาพรวม"],["income","💰 รายรับ"],["expense","📤 รายจ่าย"],["commission","💎 ค่าคอม"]].map(([k, l]) => (
          <button key={k}
            style={{ ...S.navBtn, ...(tab === k ? S.navActive : {}) }}
            onClick={() => setTab(k)}>{l}</button>
        ))}
      </nav>

      {/* Content */}
      <main style={S.main}>
        {tab === "dashboard" && (
          <Dashboard
            todayIncome={todayIncome} todayExpense={todayExpense}
            todayTx={todayTx}
            monthIncome={monthIncome} monthExpense={monthExpense}
            onDelete={delTx}
          />
        )}
        {tab === "income" && (
          <TxList
            transactions={transactions.filter(t => t.type === "income" && t.branch === branch)}
            type="income" onDelete={delTx} onAdd={() => setModal("income")}
          />
        )}
        {tab === "expense" && (
          <TxList
            transactions={transactions.filter(t => t.type === "expense" && t.branch === branch)}
            type="expense" onDelete={delTx} onAdd={() => setModal("expense")}
          />
        )}
        {tab === "commission" && (
          <CommissionTab rows={commRows} month={month} staff={staff} />
        )}
      </main>

      {/* FAB */}
      {tab === "income" && (
        <button style={{ ...S.fab, background: "linear-gradient(135deg,#d4a84b,#f0cc7a)" }}
          onClick={() => setModal("income")}>＋</button>
      )}
      {tab === "expense" && (
        <button style={{ ...S.fab, background: "linear-gradient(135deg,#b05050,#d07070)" }}
          onClick={() => setModal("expense")}>＋</button>
      )}

      {/* Modals */}
      {modal === "income" && <AddModal type="income" branch={branch} staff={staff} onSave={addTx} onClose={() => setModal(null)} />}
      {modal === "expense" && <AddModal type="expense" branch={branch} staff={staff} onSave={addTx} onClose={() => setModal(null)} />}
      {modal === "settings" && <SettingsModal staff={staff} onSave={saveStaff} onClose={() => setModal(null)} />}
    </div>
  );
}

// ─── Dashboard ────────────────────────────────────────────────────────────────
function Dashboard({ todayIncome, todayExpense, todayTx, monthIncome, monthExpense, onDelete }) {
  const net = todayIncome - todayExpense;
  const mInc = monthIncome.reduce((s, t) => s + t.amount, 0);
  const mExp = monthExpense.reduce((s, t) => s + t.amount, 0);
  const mNet = mInc - mExp;
  const dateLabel = new Date().toLocaleDateString("th-TH", { weekday: "long", year: "numeric", month: "long", day: "numeric" });

  const byCat = SERVICE_CATS.map(cat => ({
    cat, total: todayTx.filter(t => t.type === "income" && t.category === cat).reduce((s, t) => s + t.amount, 0)
  })).filter(c => c.total > 0);

  const byPay = PAYMENT_METHODS.map(pm => ({
    pm, total: todayTx.filter(t => t.type === "income" && t.paymentMethod === pm).reduce((s, t) => s + t.amount, 0)
  })).filter(c => c.total > 0);

  return (
    <div style={S.section}>
      <p style={S.dateLabel}>{dateLabel}</p>

      <p style={S.sectionLbl}>วันนี้</p>
      <div style={S.kpiGrid}>
        <KpiCard label="รายรับ" value={todayIncome} color="#d4a84b" icon="💰" />
        <KpiCard label="รายจ่าย" value={todayExpense} color="#b05050" icon="📤" />
        <KpiCard label="กำไรสุทธิ" value={net} color={net >= 0 ? "#5a9a72" : "#b05050"} icon="📈" wide />
      </div>

      <p style={{ ...S.sectionLbl, marginTop: 20 }}>เดือนนี้</p>
      <div style={S.kpiGrid}>
        <KpiCard label="รายรับรวม" value={mInc} color="#d4a84b" icon="📅" />
        <KpiCard label="รายจ่ายรวม" value={mExp} color="#b05050" icon="📅" />
        <KpiCard label="กำไรเดือน" value={mNet} color={mNet >= 0 ? "#5a9a72" : "#b05050"} icon="💹" wide />
      </div>

      {byCat.length > 0 && <>
        <p style={{ ...S.sectionLbl, marginTop: 20 }}>รายรับแยกบริการวันนี้</p>
        <div style={S.catBox}>{byCat.map(c => <CatRow key={c.cat} label={c.cat} value={c.total} color="#d4a84b" />)}</div>
      </>}

      {byPay.length > 0 && <>
        <p style={{ ...S.sectionLbl, marginTop: 14 }}>วิธีชำระเงินวันนี้</p>
        <div style={S.catBox}>{byPay.map(c => <CatRow key={c.pm} label={c.pm} value={c.total} color="#7a9abf" />)}</div>
      </>}

      <p style={{ ...S.sectionLbl, marginTop: 20 }}>รายการวันนี้ ({todayTx.length})</p>
      {todayTx.length === 0
        ? <p style={S.empty}>ยังไม่มีรายการวันนี้</p>
        : <div style={S.txList}>{todayTx.map(tx => <TxRow key={tx.id} tx={tx} onDelete={onDelete} />)}</div>
      }
    </div>
  );
}

function KpiCard({ label, value, color, icon, wide }) {
  return (
    <div style={{ ...S.kpiCard, ...(wide ? S.kpiWide : {}), borderTop: `3px solid ${color}` }}>
      <span style={S.kpiIcon}>{icon}</span>
      <p style={S.kpiLabel}>{label}</p>
      <p style={{ ...S.kpiVal, color }}>{value < 0 ? "-" : ""}฿{fmt(Math.abs(value))}</p>
    </div>
  );
}

function CatRow({ label, value, color }) {
  return (
    <div style={S.catRow}>
      <span style={S.catLabel}>{label}</span>
      <span style={{ ...S.catVal, color }}>฿{fmt(value)}</span>
    </div>
  );
}

// ─── Transaction List ─────────────────────────────────────────────────────────
function TxList({ transactions, type, onDelete, onAdd }) {
  const [filterDate, setFilterDate] = useState("");
  const filtered = filterDate ? transactions.filter(t => t.date === filterDate) : transactions;
  const total = filtered.reduce((s, t) => s + t.amount, 0);

  return (
    <div style={S.section}>
      <div style={S.listTop}>
        <input type="date" value={filterDate} onChange={e => setFilterDate(e.target.value)} style={S.dateInput} />
        <button style={{ ...S.addBtn, background: type === "income" ? "#d4a84b" : "#b05050" }} onClick={onAdd}>+ เพิ่ม</button>
      </div>
      <div style={S.totalBanner}>
        {filterDate || "ทั้งหมด"} · <strong>฿{fmt(total)}</strong>
        <span style={{ opacity: .5, fontSize: 12, marginLeft: 6 }}>({filtered.length} รายการ)</span>
      </div>
      {filtered.length === 0
        ? <p style={S.empty}>ไม่มีรายการ</p>
        : <div style={S.txList}>{filtered.map(tx => <TxRow key={tx.id} tx={tx} onDelete={onDelete} />)}</div>
      }
    </div>
  );
}

function TxRow({ tx, onDelete }) {
  const isIncome = tx.type === "income";
  const color = isIncome ? "#d4a84b" : "#b05050";
  return (
    <div style={S.txRow}>
      <div style={{ ...S.txDot, background: color }} />
      <div style={S.txInfo}>
        <p style={S.txCat}>{tx.category}{tx.staffName ? ` · ${tx.staffName}` : ""}</p>
        <p style={S.txMeta}>
          {tx.branch && <span style={S.badge}>{tx.branch === "Peaches Nails" ? "🌸 P" : "🤲 B"}</span>}
          {tx.paymentMethod && <span style={{ ...S.badge, background: "#1a1a26" }}>{tx.paymentMethod}</span>}
          <span style={S.txDate}>{tx.date}</span>
        </p>
        {tx.note && <p style={S.txNote}>{tx.note}</p>}
      </div>
      <p style={{ ...S.txAmt, color }}>{isIncome ? "+" : "-"}฿{fmt(tx.amount)}</p>
      <button style={S.delBtn} onClick={() => onDelete(tx.id)}>✕</button>
    </div>
  );
}

// ─── Commission ───────────────────────────────────────────────────────────────
function CommissionTab({ rows, month, staff }) {
  const [y, m] = month.split("-");
  const label = new Date(+y, +m - 1, 1).toLocaleDateString("th-TH", { year: "numeric", month: "long" });
  const totalComm = rows.reduce((s, r) => s + r.comm, 0);

  return (
    <div style={S.section}>
      <p style={S.sectionLbl}>ค่าคอมมิชชั่น · {label}</p>
      {rows.length === 0
        ? <p style={S.empty}>ยังไม่มีรายรับเดือนนี้</p>
        : <>
          {rows.map(r => (
            <div key={r.name} style={S.commCard}>
              <div style={S.commAvatar}>{r.name[0]}</div>
              <div style={S.commInfo}>
                <p style={S.commName}>{r.name}</p>
                <p style={S.commSub}>ยอดขาย ฿{fmt(r.sales)} · {r.commRate}%</p>
              </div>
              <div style={S.commRight}>
                <p style={S.commVal}>฿{fmt(r.comm)}</p>
                <p style={S.commLbl}>ค่าคอม</p>
              </div>
            </div>
          ))}
          <div style={S.commTotal}>รวมค่าคอมทั้งหมด <strong>฿{fmt(totalComm)}</strong></div>
        </>
      }
      <p style={{ ...S.sectionLbl, marginTop: 20 }}>อัตราค่าคอมพนักงาน</p>
      <div style={S.catBox}>
        {staff.map(s => (
          <div key={s.name} style={S.catRow}>
            <span style={S.catLabel}>{s.name}</span>
            <span style={{ fontSize: 12, color: "#555" }}>ค่าแรง ฿{fmt(s.dailyRate)}/วัน · คอม {s.commRate}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Add Modal ────────────────────────────────────────────────────────────────
function AddModal({ type, branch, staff, onSave, onClose }) {
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState(type === "income" ? SERVICE_CATS[0] : EXPENSE_CATS[0]);
  const [staffName, setStaffName] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("โอน");
  const [note, setNote] = useState("");
  const [date, setDate] = useState(todayStr());
  const [txBranch, setTxBranch] = useState(branch);
  const isIncome = type === "income";
  const accent = isIncome ? "#d4a84b" : "#b05050";

  const handleSave = () => {
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) return alert("กรุณาใส่จำนวนเงิน");
    onSave({ type, amount: amt, category, branch: txBranch, staffName: isIncome ? staffName : "", paymentMethod: isIncome ? paymentMethod : "", note, date });
  };

  return (
    <div style={S.overlay} onClick={onClose}>
      <div style={S.modal} onClick={e => e.stopPropagation()}>
        <h2 style={{ ...S.modalTitle, color: accent }}>{isIncome ? "💰 เพิ่มรายรับ" : "📤 เพิ่มรายจ่าย"}</h2>

        <Lbl>สาขา</Lbl>
        <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
          {BRANCHES.map(b => (
            <button key={b} onClick={() => setTxBranch(b)}
              style={{ ...S.branchBtn, flex: 1, ...(txBranch === b ? S.branchActive : {}) }}>{b}</button>
          ))}
        </div>

        <Lbl>วันที่</Lbl>
        <input type="date" value={date} onChange={e => setDate(e.target.value)} style={S.input} />

        <Lbl>จำนวนเงิน (฿)</Lbl>
        <input type="number" placeholder="0" value={amount} onChange={e => setAmount(e.target.value)}
          style={{ ...S.input, fontSize: 22, fontWeight: 700, color: accent }} />

        <Lbl>หมวดหมู่</Lbl>
        <select value={category} onChange={e => setCategory(e.target.value)} style={S.input}>
          {(isIncome ? SERVICE_CATS : EXPENSE_CATS).map(c => <option key={c}>{c}</option>)}
        </select>

        {isIncome && <>
          <Lbl>พนักงาน</Lbl>
          <select value={staffName} onChange={e => setStaffName(e.target.value)} style={S.input}>
            <option value="">-- ไม่ระบุ --</option>
            {staff.map(s => <option key={s.name}>{s.name}</option>)}
          </select>
          <Lbl>วิธีชำระเงิน</Lbl>
          <div style={{ display: "flex", gap: 7, marginBottom: 14 }}>
            {PAYMENT_METHODS.map(pm => (
              <button key={pm} onClick={() => setPaymentMethod(pm)}
                style={{ ...S.payBtn, ...(paymentMethod === pm ? { background: "#d4a84b", color: "#0d0d14", fontWeight: 700 } : {}) }}>{pm}</button>
            ))}
          </div>
        </>}

        <Lbl>หมายเหตุ</Lbl>
        <input type="text" placeholder="หมายเหตุ..." value={note} onChange={e => setNote(e.target.value)} style={S.input} />

        <div style={S.modalActions}>
          <button style={S.cancelBtn} onClick={onClose}>ยกเลิก</button>
          <button style={{ ...S.saveBtn, background: accent }} onClick={handleSave}>บันทึก</button>
        </div>
      </div>
    </div>
  );
}

// ─── Settings Modal ───────────────────────────────────────────────────────────
function SettingsModal({ staff: initStaff, onSave, onClose }) {
  const [list, setList] = useState(initStaff.map(s => ({ ...s })));
  const [newName, setNewName] = useState("");

  const update = (i, field, val) => {
    const next = [...list];
    next[i] = { ...next[i], [field]: field === "name" ? val : parseFloat(val) || 0 };
    setList(next);
  };

  return (
    <div style={S.overlay} onClick={onClose}>
      <div style={{ ...S.modal, maxHeight: "88vh", overflowY: "auto" }} onClick={e => e.stopPropagation()}>
        <h2 style={S.modalTitle}>⚙️ ตั้งค่าพนักงาน</h2>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 68px 60px 28px", gap: 6, marginBottom: 8, fontSize: 10, color: "#444", textTransform: "uppercase", letterSpacing: .5 }}>
          <span>ชื่อ</span><span style={{ textAlign: "center" }}>ค่าแรง/วัน</span><span style={{ textAlign: "center" }}>คอม%</span><span />
        </div>
        {list.map((s, i) => (
          <div key={i} style={{ display: "grid", gridTemplateColumns: "1fr 68px 60px 28px", gap: 6, marginBottom: 7, alignItems: "center" }}>
            <input value={s.name} onChange={e => update(i, "name", e.target.value)} style={{ ...S.input, marginBottom: 0, fontSize: 13 }} />
            <input type="number" value={s.dailyRate} onChange={e => update(i, "dailyRate", e.target.value)} style={{ ...S.input, marginBottom: 0, textAlign: "center", fontSize: 13 }} />
            <input type="number" value={s.commRate} onChange={e => update(i, "commRate", e.target.value)} style={{ ...S.input, marginBottom: 0, textAlign: "center", color: "#d4a84b", fontSize: 13 }} />
            <button style={S.delBtn} onClick={() => setList(list.filter((_, j) => j !== i))}>✕</button>
          </div>
        ))}
        <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
          <input type="text" placeholder="ชื่อพนักงานใหม่" value={newName} onChange={e => setNewName(e.target.value)}
            style={{ ...S.input, flex: 1, marginBottom: 0 }} />
          <button style={{ ...S.saveBtn, background: "#d4a84b", padding: "9px 14px" }}
            onClick={() => { if (newName.trim()) { setList([...list, { name: newName.trim(), dailyRate: 400, commRate: 10 }]); setNewName(""); } }}>
            + เพิ่ม
          </button>
        </div>
        <div style={{ ...S.modalActions, marginTop: 20 }}>
          <button style={S.cancelBtn} onClick={onClose}>ยกเลิก</button>
          <button style={{ ...S.saveBtn, background: "#d4a84b" }} onClick={() => onSave(list)}>บันทึก</button>
        </div>
      </div>
    </div>
  );
}

function Lbl({ children }) {
  return <label style={{ display: "block", fontSize: 10, color: "#555", letterSpacing: .8, marginBottom: 4, textTransform: "uppercase" }}>{children}</label>;
}

function Toast({ toast }) {
  if (!toast) return null;
  return <div style={{ ...S.toast, background: toast.type === "warn" ? "#8a3a3a" : "#3a6a50" }}>{toast.msg}</div>;
}

// ─── Styles ───────────────────────────────────────────────────────────────────
const S = {
  root: { fontFamily: "'Sarabun','Noto Sans Thai',sans-serif", background: "#0d0d14", minHeight: "100vh", color: "#ede8e0", maxWidth: 520, margin: "0 auto", paddingBottom: 88 },
  splash: { display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100vh", background: "#0d0d14" },
  splashGem: { fontSize: 48, color: "#d4a84b", marginBottom: 16 },
  splashText: { color: "#555", fontSize: 16 },
  header: { background: "linear-gradient(180deg,#16141c,#111018)", borderBottom: "1px solid #1e1c28", position: "sticky", top: 0, zIndex: 100 },
  headerRow: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "13px 16px 8px" },
  brand: { display: "flex", alignItems: "center", gap: 8 },
  gem: { color: "#d4a84b", fontSize: 15 },
  brandName: { fontWeight: 700, fontSize: 14, letterSpacing: .5, color: "#ede8e0" },
  settingsBtn: { background: "none", border: "none", color: "#d4a84b", fontSize: 20, cursor: "pointer" },
  branchRow: { display: "flex", padding: "0 16px 10px", gap: 6 },
  branchBtn: { flex: 1, background: "#1a1826", border: "1px solid #252330", borderRadius: 8, color: "#555", fontSize: 12, padding: "7px 4px", cursor: "pointer", fontFamily: "inherit", transition: "all .2s" },
  branchActive: { background: "#d4a84b", color: "#0d0d14", border: "1px solid #d4a84b", fontWeight: 700 },
  nav: { display: "flex", background: "#111018", borderBottom: "1px solid #1a1826", position: "sticky", top: 88, zIndex: 99 },
  navBtn: { flex: 1, background: "none", border: "none", color: "#444", fontSize: 11, padding: "10px 2px", cursor: "pointer", fontFamily: "inherit", borderBottom: "2px solid transparent" },
  navActive: { color: "#d4a84b", borderBottom: "2px solid #d4a84b" },
  main: { padding: "16px 16px 0" },
  section: {},
  dateLabel: { textAlign: "center", color: "#444", fontSize: 12, margin: "0 0 14px" },
  sectionLbl: { fontSize: 10, color: "#444", letterSpacing: 1, textTransform: "uppercase", margin: "0 0 8px" },
  kpiGrid: { display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 4 },
  kpiCard: { flex: "1 1 110px", background: "#16141c", borderRadius: 10, padding: "12px", display: "flex", flexDirection: "column", gap: 4 },
  kpiWide: { flex: "1 1 100%", flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  kpiIcon: { fontSize: 15 },
  kpiLabel: { margin: 0, fontSize: 11, color: "#444" },
  kpiVal: { margin: 0, fontSize: 20, fontWeight: 700 },
  catBox: { background: "#16141c", borderRadius: 10, overflow: "hidden", marginBottom: 4 },
  catRow: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "9px 14px", borderBottom: "1px solid #1a1826" },
  catLabel: { fontSize: 13, color: "#ccc" },
  catVal: { fontSize: 13, fontWeight: 700 },
  txList: { display: "flex", flexDirection: "column", gap: 7 },
  txRow: { display: "flex", alignItems: "center", gap: 9, background: "#16141c", borderRadius: 10, padding: "10px 12px" },
  txDot: { width: 7, height: 7, borderRadius: "50%", flexShrink: 0 },
  txInfo: { flex: 1, minWidth: 0 },
  txCat: { margin: 0, fontSize: 13, fontWeight: 600, color: "#ede8e0" },
  txMeta: { margin: "3px 0 0", display: "flex", alignItems: "center", gap: 4, flexWrap: "wrap" },
  badge: { fontSize: 10, background: "#1e1c28", color: "#777", borderRadius: 4, padding: "1px 5px" },
  txDate: { fontSize: 11, color: "#333" },
  txNote: { margin: "2px 0 0", fontSize: 11, color: "#444", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" },
  txAmt: { fontWeight: 700, fontSize: 14, whiteSpace: "nowrap" },
  delBtn: { background: "none", border: "none", color: "#333", cursor: "pointer", fontSize: 13, padding: 4, flexShrink: 0 },
  empty: { textAlign: "center", color: "#333", padding: "32px 0", fontSize: 13 },
  listTop: { display: "flex", gap: 8, marginBottom: 10 },
  dateInput: { flex: 1, background: "#16141c", border: "1px solid #1e1c28", borderRadius: 8, padding: "8px 10px", color: "#ede8e0", fontSize: 13, fontFamily: "inherit" },
  addBtn: { border: "none", borderRadius: 8, padding: "8px 16px", color: "#0d0d14", fontWeight: 700, cursor: "pointer", fontSize: 13, fontFamily: "inherit" },
  totalBanner: { background: "#16141c", borderRadius: 8, padding: "9px 14px", fontSize: 13, color: "#888", marginBottom: 10 },
  commCard: { display: "flex", alignItems: "center", gap: 12, background: "#16141c", borderRadius: 12, padding: "13px", marginBottom: 7 },
  commAvatar: { width: 40, height: 40, borderRadius: "50%", background: "linear-gradient(135deg,#d4a84b,#f0cc7a)", color: "#0d0d14", fontWeight: 700, fontSize: 16, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 },
  commInfo: { flex: 1 },
  commName: { margin: 0, fontWeight: 700, fontSize: 14, color: "#ede8e0" },
  commSub: { margin: "2px 0 0", fontSize: 11, color: "#444" },
  commRight: { textAlign: "right" },
  commVal: { margin: 0, fontSize: 18, fontWeight: 700, color: "#d4a84b" },
  commLbl: { margin: 0, fontSize: 10, color: "#333" },
  commTotal: { textAlign: "right", padding: "10px 0 2px", fontSize: 13, color: "#888", borderTop: "1px solid #1a1826", marginTop: 4 },
  fab: { position: "fixed", bottom: 24, right: 24, width: 54, height: 54, borderRadius: "50%", border: "none", color: "#0d0d14", fontSize: 26, fontWeight: 700, cursor: "pointer", boxShadow: "0 4px 20px rgba(212,168,75,.3)", zIndex: 200 },
  overlay: { position: "fixed", inset: 0, background: "rgba(0,0,0,.8)", zIndex: 300, display: "flex", alignItems: "flex-end", justifyContent: "center" },
  modal: { background: "#16141c", borderRadius: "18px 18px 0 0", padding: "22px 18px 30px", width: "100%", maxWidth: 520 },
  modalTitle: { margin: "0 0 16px", fontSize: 17, fontWeight: 700 },
  input: { width: "100%", background: "#0d0d14", border: "1px solid #1e1c28", borderRadius: 8, padding: "9px 11px", color: "#ede8e0", fontSize: 14, marginBottom: 12, fontFamily: "inherit", boxSizing: "border-box" },
  payBtn: { flex: 1, background: "#1a1826", border: "1px solid #1e1c28", borderRadius: 7, padding: "8px 4px", color: "#555", fontSize: 13, cursor: "pointer", fontFamily: "inherit" },
  modalActions: { display: "flex", gap: 8, marginTop: 4 },
  cancelBtn: { flex: 1, background: "#1a1826", border: "none", borderRadius: 8, padding: "12px", color: "#555", fontSize: 14, cursor: "pointer", fontFamily: "inherit" },
  saveBtn: { flex: 2, border: "none", borderRadius: 8, padding: "12px", color: "#0d0d14", fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" },
  toast: { position: "fixed", top: 54, left: "50%", transform: "translateX(-50%)", padding: "9px 20px", borderRadius: 20, fontSize: 13, fontWeight: 600, color: "#fff", zIndex: 400, whiteSpace: "nowrap", boxShadow: "0 4px 20px rgba(0,0,0,.4)" },
};
